from django.shortcuts import redirect, get_object_or_404
from .models import Post, FeedbackPost

def feedback(request):
    if request.method == 'POST':
        post_id = request.POST.get('post_id')
        feedback = request.POST.get('feedback')  # 'like' ou 'dislike'
        user = request.user

        post = get_object_or_404(Post, id=post_id)

        feedback_bool = True if feedback == 'like' else False

        feedback, created = FeedbackPost.objects.update_or_create(
            user=user,
            post=post,
            defaults={'feedback': feedback_bool}
        )

        return redirect('/post/list/')