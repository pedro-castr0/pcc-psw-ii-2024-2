from django.db import models
from django.contrib.auth.models import User
from posts.models import Post
 

# Create your models here.

class FeedbackPost(models.Model):
    feedback = models.BooleanField(null=True)
    date_time = models.DateTimeField(auto_now_add=True)
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='feedbackposts')
    post = models.ForeignKey(Post, on_delete=models.CASCADE, related_name='feedbackposts')

    class Meta:
        constraints = [
            models.UniqueConstraint(fields=['user', 'post'], name='unique_user_post_feedback')
        ]

    def get_likes(self):
        return self.feedbackposts.filter(feedback=True).count()
    
    def get_deslikes(self):
        return self.feedbackposts.filter(feedback=False).count()
    
    def karma(self):
        return self.get_likes() - self.get_deslikes()