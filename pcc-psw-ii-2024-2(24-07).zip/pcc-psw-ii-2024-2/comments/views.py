from django.shortcuts import render, redirect
from .models import Comment, Post
from django.contrib.auth.models import User
from django.contrib.auth.decorators import login_required
from django.contrib.auth.decorators import permission_required

def comment(request):
    if request.method == 'GET':
        posts = Post.objects.all()
        comments = Comment.objects.all()
    
        return render(request, 'comment/form.html', {'posts':posts, 'comments':comments})
    
    elif request.method == 'POST':
        content = request.POST.get('content')
        author_id = request.POST.get('author')
        author = User.objects.get(id = author_id)
        post_id = request.POST.get('post')
        post = Post.objects.get(id = post_id)
        reply_id = request.POST.get('reply')
        reply = Comment.objects.filter(id=reply_id).first()

        comment = Comment(
            content = content,
            author = author,
            post = post,
            reply = reply
        )

        comment.save()

    return redirect('/comment/list/')

def list(request):
    comments = Comment.objects.all()
    return render(request, 'comment/list.html', {'comments':comments})

def edit(request, id):
    posts = Post.objects.all()
    comments = Comment.objects.all()
    comment = Comment.objects.get(id = id)

    if request.method == 'POST':
        comment.content = request.POST.get('content')
        author_id = request.POST.get('author')
        comment.author = User.objects.get(id = author_id)
        post_id = request.POST.get('post')
        comment.post = Post.objects.get(id = post_id)
        reply_id = request.POST.get('reply')
        comment.reply = Comment.objects.get(id = reply_id)

        comment.save()

        return redirect('/comment/list/')
    
    return render(request, 'comment/form.html', {'comment':comment, 'comments':comments, 'posts':posts})


def delete(request, id):
    comment = Comment.objects.get(id = id)
    comment.delete()

    return redirect('/comment/list/')


