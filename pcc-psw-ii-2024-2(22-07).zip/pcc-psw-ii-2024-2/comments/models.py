from django.db import models
from community_users.models import Community_User
from posts.models import Post

# Create your models here.

class Comment(models.Model):
    content = models.TextField()
    posted = models.DateTimeField(auto_now_add=True)
    edited = models.DateTimeField(auto_now=True)
    author = models.ForeignKey(Community_User, on_delete=models.CASCADE, related_name='comments')
    post = models.ForeignKey(Post, on_delete=models.CASCADE, related_name='comments')
    reply = models.ForeignKey('self', on_delete=models.CASCADE, related_name='replies', null=True, blank=True)

    def return_author(self):
        return self.author.return_name()
    
    def return_title(self):
        return self.post.return_title()

