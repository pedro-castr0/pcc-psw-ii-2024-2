from django.shortcuts import render, redirect
from .models import Community, Community_User, Post
from django.contrib.auth.decorators import login_required
from django.contrib.auth.decorators import permission_required

def create(request):
    if request.method == 'GET':
        communities = Community.objects.all()
        community_users = Community_User.objects.all()
    
        return render(request, 'post/form.html', {'communities':communities, 'community_users':community_users})
    
    elif request.method == 'POST':
        title = request.POST.get('title')
        content = request.POST.get('content')
        tag = request.POST.get('tag')
        author_id = request.POST.get('author')
        author = Community_User.objects.get(id = author_id)
        community_id = request.POST.get('community')
        community = Community.objects.get(id = community_id) 

        post = Post(
            title = title,
            content = content,
            tag = tag,
            author = author,
            community = community
        )

        post.save()

    return redirect('/post/list/')

def list(request):
    posts = Post.objects.all()
    return render(request, 'post/list.html', {'posts':posts})

def edit(request, id):
    communities = Community.objects.all()
    community_users = Community_User.objects.all()
    post = Post.objects.get(id = id)

    if request.method == 'POST':
        post.title = request.POST.get('title')
        post.content = request.POST.get('content')
        post.tag = request.POST.get('tag')
        author_id = request.POST.get('author')
        post.author = Community_User.objects.get(id = author_id)
        community_id = request.POST.get('community')
        post.community = Community.objects.get(id = community_id)

        post.save()

        return redirect('/post/list/')
    
    return render(request, 'post/form.html', {'communities':communities, 'community_users':community_users, 'post':post})


def delete(request, id):
    post = post.objects.get(id = id)
    post.delete()

    return redirect('/post/list/')


