from django.db import models
from community_users.models import Community_User


# Create your models here.

class Community(models.Model):
    name = models.CharField(max_length=100)
    description = models.CharField(max_length=500)
    tag = models.CharField(max_length=100)
    created = models.DateField(auto_now_add=True)
    creator = models.ForeignKey(Community_User, on_delete=models.CASCADE, related_name='communities')

    def return_name(self):
        return self.name

    def return_creator(self):
        return self.creator.return_name()
    
    

