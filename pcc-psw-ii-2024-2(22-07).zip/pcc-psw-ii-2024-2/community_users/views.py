from django.shortcuts import render, redirect
from .models import Community_User
from django.contrib.auth.decorators import login_required
from django.contrib.auth.decorators import permission_required

def create(request):
    if request.method == 'GET':
        return render(request, 'community_user/form.html')
    
    elif request.method == 'POST':
        username = request.POST.get('username')
        email = request.POST.get('email')
        password = request.POST.get('password')


        community_user = Community_User(
            username = username,
            email = email,
            password = password
        )

        community_user.save()

    return redirect('/user/list/')

def list(request):
    community_users = Community_User.objects.all()
    return render(request, 'community_user/list.html', {'community_users':community_users})

def edit(request, id):
    community_user = Community_User.objects.get(id = id)

    if request.method == 'POST':
        community_user.username = request.POST.get('username')
        community_user.email = request.POST.get('email')
        community_user.password = request.POST.get('password')

        community_user.save()

        return redirect('/user/list/')
    
    return render(request, 'community_user/form.html', {'community_user':community_user})


def delete(request, id):
    community_user = Community_User.objects.get(id = id)
    community_user.delete()

    return redirect('/user/list/')


